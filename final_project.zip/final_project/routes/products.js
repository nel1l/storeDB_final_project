const express = require("express");
const Product = require("../models/Product");
const { auth, isAdmin } = require("../middlewares/authMiddleware");
const router = express.Router();

router.get("/", async (req, res) => {
  const products = await Product.find();
  res.json(products);
});

router.post("/", auth, isAdmin, async (req, res) => {
  const product = new Product(req.body);
  await product.save();
  res.json(product);
});

router.put("/:id", auth, isAdmin, async (req, res) => {
  const updatedProduct = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(updatedProduct);
});

router.delete("/:id", auth, isAdmin, async (req, res) => {
  await Product.findByIdAndDelete(req.params.id);
  res.json({ message: "Товар удален" });
});

module.exports = router;
