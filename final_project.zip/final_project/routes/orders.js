const express = require("express");
const Order = require("../models/Order");
const { auth, isAdmin } = require("../middlewares/authMiddleware");
const router = express.Router();
const Product = require("../models/Product");

router.post("/", auth, async (req, res) => {
  try {
    const { products } = req.body;
    const productDetails = await Product.find({ _id: { $in: products } });

    if (productDetails.length !== products.length) {
      return res.status(400).json({ message: "Один или несколько товаров не найдены" });
    }

    const order = new Order({
      userId: req.user.id,
      products: productDetails.map(product => ({
        productId: product._id,
        name: product.name,
        price: product.price,
        color: product.color
      }))
    });

    await order.save();
    res.json(order);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.delete("/:id", auth, isAdmin, async (req, res) => {
  await Order.findByIdAndDelete(req.params.id);
  res.json({ message: "Заказ удален" });
});

module.exports = router;
