const mongoose = require("mongoose");

const OrderSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  products: [
    {
      productId: { type: mongoose.Schema.Types.ObjectId, ref: "Product" },
      name: String,
      price: Number, 
      color: String
    }
  ],
  status: { type: String, enum: ["pending", "shipped", "delivered"], default: "pending" }
});

OrderSchema.index({ userId: 1 });

module.exports = mongoose.model("Order", OrderSchema);
