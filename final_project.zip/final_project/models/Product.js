const mongoose = require("mongoose");

const ProductSchema = new mongoose.Schema({
  name: { type: String, required: true },
  url: String,
  price: { type: Number, required: true },
  price_url: String,
  color: String,
  details: String,
});

ProductSchema.index({ name: 1 });

module.exports = mongoose.model("Product", ProductSchema);
